__NOTICE__

__This addon is no longer maintained by me, if you are interested in taking it over then please contact me via the Issues section. (You are welcome to submit it to the official Kodi Repo - just make sure you remove my name from it before you do it)__


![EBooks](icon.png)

eBooks is an addon that allows you to list and view your epub, mobi and pdf eBooks using Kodi.

After installation go to settings and point it to the directory containing your eBooks. Then you can navigate to the eBooks addon in the "Programs" section to view your eBooks. For more information on it's features please see the wiki:

[Add-on:EBooks](https://github.com/robwebset/script.ebooks/wiki)
